﻿if (document.body.innerHTML.includes('Atenção: sua consulta será auditada!')) {
    localStorage.setItem('pula_tela_inicial', 'pula');
}